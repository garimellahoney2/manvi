package com.example.loginpage;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
 Button cancel,login,newregister;
 EditText e1,e2;
 SQLiteDatabase db;
 Cursor c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cancel = (Button)findViewById(R.id.button2);
        login = (Button)findViewById(R.id.button);
        newregister = (Button)findViewById(R.id.button4);
        e1 = (EditText)findViewById(R.id.editText2);
        e2 = (EditText)findViewById(R.id.editText4);
        try
        {
         db = openOrCreateDatabase("logindb", Context.MODE_PRIVATE,null);
         db.execSQL("CREATE TABLE IF NOT EXISTS logintable(username VARCHAR,password VARCHAR)");
         c = db.rawQuery("SELECT * FROM logintable",null);
        }catch(Exception e)
        {
            Toast.makeText(getBaseContext(), "Error:"+e.getMessage().toString(), Toast.LENGTH_LONG).show();
        }
        if(!c.moveToFirst())
        {
            Intent i = new Intent(getBaseContext(),NewUser.class);
            startActivity(i);
        }
        else
        {
           try
           {

           }catch(Exception e)
           {
               Toast.makeText(getBaseContext(), "Error:"+e.getMessage().toString(), Toast.LENGTH_LONG).show();
           }
        }
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int flag = 0;
                do {

                    if (e1.getText().toString().equals(c.getString(0)) && e2.getText().toString().equals(c.getString(1))) {
                        Intent i = new Intent(getBaseContext(), Main2Activity.class);
                        startActivity(i);
                        flag = 1;
                        break;//else c.moveToNext will go to upto last
                        /*Toast.makeText(getBaseContext(),"hi hello",Toast.LENGTH_LONG).show();*/
                    }
                }while(c.moveToNext());
                if(flag==0)
                {
                    Toast.makeText(getBaseContext(), "Invalid User Name or Pasword", Toast.LENGTH_LONG).show();
                }
            }
        });
        newregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getBaseContext(),NewUser.class);
                startActivity(i);
            }
        });
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishActivity(0);
                System.exit(0);
            }
        });

    }
}
