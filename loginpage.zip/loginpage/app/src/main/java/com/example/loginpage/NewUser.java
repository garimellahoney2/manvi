package com.example.loginpage;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class NewUser extends AppCompatActivity {
EditText e1,e2,e3;
Button register;
SQLiteDatabase db;
Cursor c;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);
        e1= (EditText)findViewById(R.id.editText2);
        e2= (EditText)findViewById(R.id.editText4);
        e3= (EditText)findViewById(R.id.editText5);
        register = (Button)findViewById(R.id.button);
        try
        {
            db = openOrCreateDatabase("logindb", Context.MODE_PRIVATE,null);
            db.execSQL("CREATE TABLE IF NOT EXISTS logintable(username VARCHAR,password VARCHAR)");
           c = db.rawQuery("SELECT * FROM logintable",null);
        }
        catch(Exception e)
        {
            Toast.makeText(getBaseContext(),"Error:"+e.getMessage().toString(),Toast.LENGTH_LONG).show();
        }
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                        c.moveToFirst();
                        int flag = 0;
                        do {
                            if(e1.getText().toString().equals(c.getString(0)))
                            {
                                flag = 1;
                            }
                        }while(c.moveToNext());
                        if(flag==0)
                        {
                            if (e2.getText().toString().equals(e3.getText().toString()) && !e1.getText().toString().equals("")) {
                                db.execSQL("INSERT INTO logintable VALUES('" + e1.getText().toString() + "','" + e2.getText().toString() + "');");
                                Toast.makeText(getBaseContext(), "again login for security", Toast.LENGTH_LONG).show();
                                flag = 1;
                                //db.execSQL("INSERT INTO logintable VALUES('"+e1.getText().toString()+"','"+e2.getText().toString()+"');");
                                db.close();
                                Intent i= new Intent(getBaseContext(),MainActivity.class);//don't paste in last else it may load in many activities
                                startActivity(i);
                            } else if(!e2.getText().toString().equals(e3.getText().toString())) {
                                //here write load again this activity
                                Toast.makeText(getBaseContext(), "Pasword Not Matching!", Toast.LENGTH_LONG).show();
                                Intent i= new Intent(getBaseContext(),NewUser.class);
                                startActivity(i);
                            }
                        }
                       else if(flag==1)
                        {
                            Toast.makeText(getBaseContext(), "already user existed", Toast.LENGTH_LONG).show();
                        }

            }
        });

    }
}
